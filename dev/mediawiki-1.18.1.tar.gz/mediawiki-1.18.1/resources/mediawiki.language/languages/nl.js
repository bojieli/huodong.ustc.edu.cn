/**
 * Dutch (Nederlands) language functions
 */

mediaWiki.language.digitTransformTable = {
    '.' : ',',
    ',' : '.'
};
