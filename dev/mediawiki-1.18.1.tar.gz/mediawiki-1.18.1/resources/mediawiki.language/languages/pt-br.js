/**
 * Brazilian Portugese (Portuguêsi do Brasil) language functions
 */

mediaWiki.language.digitTransformTable = {
    '.' : ',',
    ',' : ' '
};
